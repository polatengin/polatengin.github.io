﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace DataTable_vs_DataReader
{
  public partial class frmMain : Form
  {
    public frmMain()
    {
      InitializeComponent();
    }

    private void frmMain_Load(object sender, EventArgs e)
    {
      cmbTekrarAdet.SelectedIndex = 1;
      using (SqlConnection c = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=AdventureWorks2008R2;Data Source=."))
      {
        c.Open();
        SqlCommand sc = new SqlCommand("PR_TABLO_LISTESI", c);
        sc.CommandType = CommandType.StoredProcedure;

        SqlDataReader dr = sc.ExecuteReader();
        while (dr.Read())
        {
          ListViewItem oItem = new ListViewItem(new string[] { dr["TABLO_ADI"].ToString(), dr["SATIR_SAYISI"].ToString() });
          lvTablolar.Items.Add(oItem);
        }

        c.Close();
      }
    }

    private int TekrarAdet = 0;
    private string Tablo = string.Empty;
    private int DataTableSure = 0;
    private int DataReaderSure = 0;

    private void btnBaslat_Click(object sender, EventArgs e)
    {
      if (lvTablolar.SelectedItems.Count == 0)
      {
        MessageBox.Show("Önce bir tablo seçmelisiniz!!", "Uyarı!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      Tablo = lvTablolar.SelectedItems[0].Text;
      switch (cmbTekrarAdet.SelectedIndex)
      {
        case 0:
          TekrarAdet = 20;
          break;
        case 1:
          TekrarAdet = 10;
          break;
        case 2:
          TekrarAdet = 5;
          break;
      }

      lblDataTable.Text = string.Format("{0} milisaniye", 0);
      lblDataReader.Text = string.Format("{0} milisaniye", 0);
      lblSonuc.Text = string.Empty;

      cmbTekrarAdet.Enabled = false;
      btnBaslat.Enabled = false;
      lvTablolar.Enabled = false;

      this.Cursor = Cursors.WaitCursor;

      this.Invalidate();
      Application.DoEvents();

      Thread thYaris = new Thread(YarisBaslasin);
      thYaris.Start();
    }

    private void YarisBaslasin()
    {
      if (lblDataTable.InvokeRequired)
      {
        lblDataTable.Invoke(new MethodInvoker(YarisBaslasin));
      }
      else
      {
        DataTableHesapla();
        DataReaderHesapla();

        lblDataTable.Text = string.Format("{0:0,0} milisaniye", DataTableSure);
        lblDataReader.Text = string.Format("{0:0,0} milisaniye", DataReaderSure);

        if (DataTableSure > DataReaderSure)
        {
          int Fark = DataTableSure - DataReaderSure;
          float Yuzde = 1 - ((float)DataReaderSure / (float)DataTableSure);
          lblSonuc.Text = string.Format("DataReader daha hızlı.{0}Fark: {1:0,0} milisaniye ({2:#.##%})", Environment.NewLine, Fark, Yuzde);
        }
        else
        {
          int Fark = DataReaderSure - DataTableSure;
          float Yuzde = 1 - ((float)DataTableSure / (float)DataReaderSure);
          lblSonuc.Text = string.Format("DataTable daha hızlı.{0}Fark: {1:0,0} milisaniye ({2:#.##%})", Environment.NewLine, Fark, Yuzde);
        }

        cmbTekrarAdet.Enabled = true;
        btnBaslat.Enabled = true;
        lvTablolar.Enabled = true;

        this.Cursor = Cursors.Default;
      }
    }

    private void DataTableHesapla()
    {
      int Tekrar = TekrarAdet;
      DateTime Baslangic = DateTime.Now;
      while (Tekrar-- > 0)
      {
        using (SqlConnection c = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=AdventureWorks2008R2;Data Source=."))
        {
          c.Open();
          SqlCommand sc = new SqlCommand("SELECT * FROM " + Tablo + " WITH (NOLOCK)", c);
          SqlDataAdapter da = new SqlDataAdapter(sc);
          DataTable dt = new DataTable();
          da.Fill(dt);
          foreach (DataRow dr in dt.Rows)
          {
            int FirstColumn = (int)dr[0];
          }
          c.Close();
        }
      }
      DataTableSure = (int)(DateTime.Now - Baslangic).TotalMilliseconds;
    }

    private void DataReaderHesapla()
    {
      int Tekrar = TekrarAdet;
      DateTime Baslangic = DateTime.Now;
      while (Tekrar-- > 0)
      {
        using (SqlConnection c = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=AdventureWorks2008R2;Data Source=."))
        {
          c.Open();
          SqlCommand sc = new SqlCommand("SELECT * FROM " + Tablo + " WITH (NOLOCK)", c);
          SqlDataReader dr = sc.ExecuteReader();
          while (dr.Read())
          {
            int FirstColumn = dr.GetInt32(0);
          }
          c.Close();
        }
      }
      DataReaderSure = (int)(DateTime.Now - Baslangic).TotalMilliseconds;
    }
  }
}