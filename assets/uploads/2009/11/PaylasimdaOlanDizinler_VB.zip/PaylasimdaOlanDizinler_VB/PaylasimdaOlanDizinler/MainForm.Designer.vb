﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
Private Sub InitializeComponent()
    Me.lbDizinler = New System.Windows.Forms.ListBox()
    Me.btnDizinleriListele = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'lbDizinler
    '
    Me.lbDizinler.FormattingEnabled = True
    Me.lbDizinler.Location = New System.Drawing.Point(12, 12)
    Me.lbDizinler.Name = "lbDizinler"
    Me.lbDizinler.Size = New System.Drawing.Size(418, 342)
    Me.lbDizinler.TabIndex = 0
    '
    'btnDizinleriListele
    '
    Me.btnDizinleriListele.Location = New System.Drawing.Point(255, 367)
    Me.btnDizinleriListele.Name = "btnDizinleriListele"
    Me.btnDizinleriListele.Size = New System.Drawing.Size(175, 25)
    Me.btnDizinleriListele.TabIndex = 1
    Me.btnDizinleriListele.Text = "Paylaşımda Olan Dizinleri Listele"
    Me.btnDizinleriListele.UseVisualStyleBackColor = True
    '
    'MainForm
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(442, 403)
    Me.Controls.Add(Me.btnDizinleriListele)
    Me.Controls.Add(Me.lbDizinler)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "MainForm"
    Me.ShowIcon = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Paylaşımda Olan Dizinler"
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents lbDizinler As System.Windows.Forms.ListBox
  Friend WithEvents btnDizinleriListele As System.Windows.Forms.Button

End Class
