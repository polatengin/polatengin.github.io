﻿Imports System.Management

Public Class MainForm

  Private Sub btnDizinleriListele_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDizinleriListele.Click
    'WMI sorgusu çalıştırıyoruz.
    Dim mos As New ManagementObjectSearcher("SELECT * FROM Win32_Share")

    'Win32_Share classı :
    'class Win32_Share : CIM_LogicalElement
    '{
    ' uint32   AccessMask;
    ' boolean  AllowMaximum;
    ' string   Caption;
    ' string   Description;
    ' datetime InstallDate;
    ' uint32   MaximumAllowed;
    ' string   Name;
    ' string   Path;
    ' string   Status;
    ' uint32   Type;
    '};
    For Each dizin As ManagementObject In mos.Get()
      lbDizinler.Items.Add(String.Format("Dizin : {0}\\{1} ({2})", dizin("Path"), dizin("Name"), dizin("Description")))
    Next
  End Sub

End Class