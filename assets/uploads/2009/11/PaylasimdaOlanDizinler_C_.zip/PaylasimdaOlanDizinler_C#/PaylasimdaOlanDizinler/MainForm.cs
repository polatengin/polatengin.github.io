﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;

namespace PaylasimdaOlanDizinler
{
  public partial class MainForm : Form
  {
    public MainForm()
    {
      InitializeComponent();
    }

    private void btnDizinleriListele_Click(object sender, EventArgs e)
    {
      //WMI sorgusu çalıştırıyoruz.
      ManagementObjectSearcher mos = new ManagementObjectSearcher("SELECT * FROM Win32_Share");

      //Win32_Share classı :
      /*
        class Win32_Share : CIM_LogicalElement
        {
          uint32   AccessMask;
          boolean  AllowMaximum;
          string   Caption;
          string   Description;
          datetime InstallDate;
          uint32   MaximumAllowed;
          string   Name;
          string   Path;
          string   Status;
          uint32   Type;
        };
       */
      foreach (ManagementObject dizin in mos.Get())
        lbDizinler.Items.Add(string.Format("Dizin : {0}\\{1} ({2})", dizin["Path"], dizin["Name"], dizin["Description"]));
    }
  }
}