﻿namespace PaylasimdaOlanDizinler
{
  partial class MainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.lbDizinler = new System.Windows.Forms.ListBox();
      this.btnDizinleriListele = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lbDizinler
      // 
      this.lbDizinler.FormattingEnabled = true;
      this.lbDizinler.Location = new System.Drawing.Point(12, 12);
      this.lbDizinler.Name = "lbDizinler";
      this.lbDizinler.Size = new System.Drawing.Size(418, 342);
      this.lbDizinler.TabIndex = 0;
      // 
      // btnDizinleriListele
      // 
      this.btnDizinleriListele.Location = new System.Drawing.Point(255, 367);
      this.btnDizinleriListele.Name = "btnDizinleriListele";
      this.btnDizinleriListele.Size = new System.Drawing.Size(175, 25);
      this.btnDizinleriListele.TabIndex = 1;
      this.btnDizinleriListele.Text = "Paylaşımda Olan Dizinleri Listele";
      this.btnDizinleriListele.UseVisualStyleBackColor = true;
      this.btnDizinleriListele.Click += new System.EventHandler(this.btnDizinleriListele_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(442, 403);
      this.Controls.Add(this.btnDizinleriListele);
      this.Controls.Add(this.lbDizinler);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "MainForm";
      this.ShowIcon = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Paylaşımda Olan Dizinler";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.ListBox lbDizinler;
    private System.Windows.Forms.Button btnDizinleriListele;
  }
}